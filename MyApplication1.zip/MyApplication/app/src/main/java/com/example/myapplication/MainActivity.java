package com.example.myapplication;

import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText eTxtnumber;
    private TextView txtResult;
    private Button btnCheck, btnRefresh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eTxtnumber = findViewById(R.id.eTxtnumber);
        txtResult = findViewById(R.id.txt3);
        btnCheck = findViewById(R.id.btncheck);
        btnRefresh = findViewById(R.id.btnrefresh);

        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = eTxtnumber.getText().toString();
                if (!input.isEmpty()) {
                    int number = Integer.parseInt(input);
                    if (isPrime(number)) {
                        txtResult.setText(number + " là số nguyên tố");
                    } else {
                        txtResult.setText(number + " không phải là số nguyên tố");
                    }
                } else {
                    txtResult.setText("Vui lòng nhập một số.");
                }
            }
        });

        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eTxtnumber.setText("");
                txtResult.setText("");
            }
        });
    }

    private boolean isPrime(int number) {
        if (number <= 1) return false;
        if (number == 2) return true;
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) return false;
        }
        return true;
    }
}